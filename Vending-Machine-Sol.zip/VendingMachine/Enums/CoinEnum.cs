﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VendingMachine.Enums
{
    public enum CoinEnum
    {
        Quarter = 25,
		Dime = 10,
		Nickle = 5
    }
}
